#!/usr/bin/env bash
# Run the DtA v2 importer. Uses ./venv if present, else ./vendor on PYTHONPATH.
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ -x "$HERE/venv/bin/python" ]; then
  PY="$HERE/venv/bin/python"; export PYTHONPATH="$HERE/src"
else
  PY="$(command -v python3)"; export PYTHONPATH="$HERE/src:$HERE/vendor"
fi
exec "$PY" -m netbox_importer_v2.cli "$@"
