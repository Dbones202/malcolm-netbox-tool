# DtA NetBox v2 — Offline Deploy (air-gapped)

Target: Malcolm host, x86_64, python3 (tested 3.13). No internet used.
NOTE: Malcolm's base python has no venv/ensurepip, so install.sh installs into ./vendor
(no venv needed). netbox-v2.sh uses ./venv if present, else ./vendor automatically.

## Install
    ./install.sh

## Run (per site; fresh box order: dump -> reset -> seed -> dump)
    ./netbox-v2.sh dump                --env-file src/netbox_importer_v2/delta_env.txt
    ./netbox-v2.sh reset --apply       --env-file src/netbox_importer_v2/delta_env.txt
    ./netbox-v2.sh seed  --apply       --env-file src/netbox_importer_v2/delta_env.txt
Omega site: same three with omega_env.txt.
